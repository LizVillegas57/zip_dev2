Starter Kit for Web Components with Webpack as application bundler.

## Installation
* cd web-components-starter-kit
* yarn install
* yarn start
* visit `http://localhost:8080`
